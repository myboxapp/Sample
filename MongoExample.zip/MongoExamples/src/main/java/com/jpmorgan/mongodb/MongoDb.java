package com.jpmorgan.mongodb;

import java.net.UnknownHostException;

import com.mongodb.DB;
import com.mongodb.MongoClient;

public class MongoDb {
    
    private static MongoClient client;
    
    public static MongoClient getClient() {
        
        try {
            if (client == null) {
                client = new MongoClient( "localhost" , 27017 );
            }
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
        
        return client;
        
    }

    public static DB getWorldDb() {
        return MongoDb.getClient().getDB( "world" );
    }
    
}
