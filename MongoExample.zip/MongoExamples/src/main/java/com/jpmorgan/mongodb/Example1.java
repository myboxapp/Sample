package com.jpmorgan.mongodb;

import java.util.List;

import com.mongodb.DB;
import com.mongodb.MongoClient;

public class Example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		MongoClient mongoClient = new MongoClient();
		List<String> dbs = mongoClient.getDatabaseNames();
		for(String db : dbs){
			DB d = mongoClient.getDB(db);
			System.out.println("Database:"+db+" - Collections:"+d.getCollectionNames());
		}
		}catch(Exception ex){
			ex.printStackTrace();
		}

	}

}
