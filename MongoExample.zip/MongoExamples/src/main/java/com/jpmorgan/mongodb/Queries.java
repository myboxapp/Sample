package com.jpmorgan.mongodb;

import java.util.Arrays;
import java.util.List;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

public class Queries {
    
    public static void main(String[] args) {
        
        TestData.countriesTestData();
        
        DB db = MongoDb.getWorldDb();
        DBCollection countries = db.getCollection("countries");
        
        //------------------------------------------------- equality
        
        DBObject equalityQuery = new BasicDBObject("area", 26900);
        DBCursor equalityCursor = countries.find(equalityQuery);
        
        displayDocumentsFromCursor(equalityCursor);
        
        //------------------------------------------------- not equal to
        
        DBObject notEqualsQuery = new BasicDBObject("area",  new BasicDBObject("$ne", 26900));
        DBCursor notEqualsCursor = countries.find(notEqualsQuery);

        displayDocumentsFromCursor(notEqualsCursor);
        
        //------------------------------------------------- less than
        
        DBObject lessThanQuery = new BasicDBObject("area",  new BasicDBObject("$lt", 50000));
        DBCursor lessThanCursor = countries.find(lessThanQuery);
        
        displayDocumentsFromCursor(lessThanCursor);
        
        //------------------------------------------------- between
        
        DBObject betweenQuery = new BasicDBObject("population", new BasicDBObject("$gt", 10000000).append("$lt", 30000000));
        DBCursor betweenCursor = countries.find(betweenQuery);

        displayDocumentsFromCursor(betweenCursor);

        //------------------------------------------------- and
        
        BasicDBObject andQuery = new BasicDBObject("area", new BasicDBObject("$lt", 500000));  
        andQuery.append("population", new BasicDBObject("$gt", 30000000));
        DBCursor andCursor = countries.find(andQuery);
        
        displayDocumentsFromCursor(andCursor);
        
        //------------------------------------------------- or
        
        DBObject areaLessThanTest = new BasicDBObject("area", new BasicDBObject("$lt", 50000));  
        DBObject populationTest = new BasicDBObject("population", new BasicDBObject("$gt", 30000000));
        
        BasicDBList or = new BasicDBList();
        or.add(areaLessThanTest);
        or.add(populationTest);
        DBObject orQuery = new BasicDBObject("$or", or);
        
        DBCursor orCursor = countries.find(orQuery);
        
        displayDocumentsFromCursor(orCursor);
        
        //------------------------------------------------- and / or
        
        DBObject areaBetweenTest = new BasicDBObject("area", new BasicDBObject("$gt", 10000).append("$lt", 30000) );
        DBObject smallerPopulationTest = new BasicDBObject("population", new BasicDBObject("$gt", 22000000)); 
        
        BasicDBList andOr = new BasicDBList();
        andOr.add(areaBetweenTest);
        andOr.add(smallerPopulationTest);
        DBObject andOrQuery = new BasicDBObject("$or", andOr);
        
        DBCursor andOrCursor = countries.find(andOrQuery);
        
        displayDocumentsFromCursor(andOrCursor);
        
        //------------------------------------------------- in list
        
        List<String> countryList = Arrays.asList(new String[] {"Ghana", "Gambia"});
        
        DBObject inListQuery = new BasicDBObject("name", new BasicDBObject("$in", countryList));
        DBCursor inListCursor = countries.find(inListQuery);
        
        displayDocumentsFromCursor(inListCursor);

        //------------------------------------------------- regular expression

        DBObject regexQuery = new BasicDBObject("name", new BasicDBObject("$regex", "G[ae].*"));
        DBCursor regexCursor = countries.find(regexQuery);
        
        displayDocumentsFromCursor(regexCursor);
        
        //------------------------------------------------- multiple columns
        
        DBObject multiColumnQuery = new BasicDBObject("area", new BasicDBObject("$lt", 100000))
                                                   .append("population", new BasicDBObject("$gt", 10000000));
        DBCursor multiColumnCursor = countries.find(multiColumnQuery);
        
        displayDocumentsFromCursor(multiColumnCursor);

        //------------------------------------------------- subdocument
        
        DBObject subdocumentQuery = new BasicDBObject("continent.name", "Europe");
        DBCursor subdocumentCursor = countries.find(subdocumentQuery);
        
        displayDocumentsFromCursor(subdocumentCursor);
        
        //------------------------------------------------- array
        
        DBCollection megacities = db.getCollection("megacities");
        
        // array must match exactly
        DBObject fullArrayMatchQuery = (DBObject) JSON.parse("{cities : {name : 'Buenos Aires', population : 14300000, growth : 1 }}");
        DBCursor arrayCursor = megacities.find(fullArrayMatchQuery);
        
        displayDocumentsFromCursor(arrayCursor);

        
        DBObject arrayElementQuery = new BasicDBObject("cities.growth", 2);
        DBCursor arrayElementCursor = megacities.find(arrayElementQuery);
        
        displayDocumentsFromCursor(arrayElementCursor);

        
        DBObject specificElementQuery = new BasicDBObject("cities.0.growth", 2);
        DBCursor specificElementCursor = megacities.find(specificElementQuery);
        
        displayDocumentsFromCursor(specificElementCursor);

        
        // returns a document if any city has a growth of 2 and any city population is greater than 23000000 (can be different city)
        DBObject multipleElementsQuery = new BasicDBObject("cities.growth", 2).append("cities.population", new BasicDBObject("$gt", 23000000));
        DBCursor multipleElementsCursor = megacities.find(multipleElementsQuery);
        
        displayDocumentsFromCursor(multipleElementsCursor);
    
    }

    //------------------------------------------------- display results

    private static void displayDocumentsFromCursor(DBCursor countryCursor) {
        System.out.println("\n" + countryCursor);
        try {
            while(countryCursor.hasNext()) {
                System.out.println("  " + countryCursor.next());
            }
        } finally {
            countryCursor.close();
        }
    }

}