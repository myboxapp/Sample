package com.jpmorgan.mongodb;

import java.net.UnknownHostException;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;

public class Example2 {

	public static void main(String[] args) {
			 
		    try {
		    
			MongoClient mongo = new MongoClient("localhost", 27017);
			DB db = mongo.getDB("authdb");
		 
			boolean auth = db.authenticate("admin", "demo1".toCharArray());
			if (auth) {
		 
				DBCollection table = db.getCollection("user");	 
				BasicDBObject document = new BasicDBObject();
				document.put("name", "mkyong");
				table.insert(document);
		 
				System.out.println("Login is successful!");
			} else {
				System.out.println("Login is failed!");
			}
			System.out.println("Done");
		 
		    } catch (UnknownHostException e) {
			e.printStackTrace();
		    } catch (MongoException e) {
			e.printStackTrace();
		    }
		  }

	}

