package com.jpmorgan.mongodb.springdata;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;



@RunWith(Suite.class)
@Suite.SuiteClasses( {
    
    CityRepositoryTest.class,
    ContinentRepositoryTest.class,
    CountryRepositoryTest.class,
    MedalsRepositoryTest.class,
    OceanRepositoryTest.class,
    StateRepositoryTest.class,

})

public class TestSuite {}