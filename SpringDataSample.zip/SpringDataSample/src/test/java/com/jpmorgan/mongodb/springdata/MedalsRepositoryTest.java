package com.jpmorgan.mongodb.springdata;

import static org.hamcrest.core.IsEqual.*; 
import static org.hamcrest.core.Is.*; 
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jpmorgan.mongodb.springdata.config.MongoConfig;
import com.jpmorgan.mongodb.springdata.domain.OlympicMedals;
import com.jpmorgan.mongodb.springdata.domain.OlympicMedals.MedalType;
import com.jpmorgan.mongodb.springdata.repository.MedalsRepository;



@ContextConfiguration(classes={MongoConfig.class})
@RunWith(SpringJUnit4ClassRunner.class)
public class MedalsRepositoryTest {

    @Autowired private MedalsRepository medalsRepo;
    
    @Before
    public void reset() {
        TestData.medals();
    }
    
    //------------------------------------------------- manual implementation

    @Test
    public void testMedalCountReturnsCorrectNumber() {
        assertThat(medalsRepo.getBronzeCount("China"), equalTo(128));
        assertThat(medalsRepo.getSilverCount("East Germany"), equalTo(129));
        assertThat(medalsRepo.getGoldCount("Italy"), equalTo(198));
    }
    
    //------------------------------------------------- spring implementation
    
    @Test
    public void testFindByCountryNameReturnsCorrectDocument() {
        OlympicMedals medals = medalsRepo.findByCountryName("China");
        assertThat(medals.getMedalCount(MedalType.GOLD), equalTo(201));
    }
}