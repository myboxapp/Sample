package com.jpmorgan.mongodb.springdata.repository;

import java.math.BigInteger;

import org.springframework.data.repository.Repository;

import com.jpmorgan.mongodb.springdata.domain.OlympicMedals;


public interface MedalsRepository extends Repository<OlympicMedals, BigInteger>,
                                          MedalsRepositoryCustom {
    
    public OlympicMedals findByCountryName(String name);

}