package com.jpmorgan.mongodb.springdata.template;

public interface TemplatePackage {

}
