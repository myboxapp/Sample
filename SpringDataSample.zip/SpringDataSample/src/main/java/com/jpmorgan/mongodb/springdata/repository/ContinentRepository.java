package com.jpmorgan.mongodb.springdata.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.jpmorgan.mongodb.springdata.domain.Continent;



public interface ContinentRepository extends CrudRepository<Continent, Long> {
    
    public Continent findByName(String name);

    public List<Continent> findByNameStartingWithIgnoreCase(String start);
    
}