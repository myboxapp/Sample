package com.jpmorgan.mongodb.springdata.repository;

import java.math.BigInteger;

import org.springframework.data.repository.CrudRepository;

import com.jpmorgan.mongodb.springdata.domain.City;



public interface CityRepository extends CrudRepository<City, BigInteger> {

    public City findByName(String name);
    
}