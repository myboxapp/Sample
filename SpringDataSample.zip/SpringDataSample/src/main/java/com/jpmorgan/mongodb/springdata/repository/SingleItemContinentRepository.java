package com.jpmorgan.mongodb.springdata.repository;

import java.math.BigInteger;

import com.jpmorgan.mongodb.springdata.domain.Continent;


public interface SingleItemContinentRepository 
            extends SingleItemOnlyRepository<Continent, BigInteger> {
    
}
