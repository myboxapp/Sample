package com.jpmorgan.mongodb.springdata.repository;

public interface RepositoryPackage {

}
