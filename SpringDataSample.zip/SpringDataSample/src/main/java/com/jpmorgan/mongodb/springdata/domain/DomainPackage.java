package com.jpmorgan.mongodb.springdata.domain;

public interface DomainPackage {

}
