package com.jpmorgan.mongodb;

import java.net.UnknownHostException;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;

public class Example3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stubry
		try {
		   MongoClient mongoClient = new MongoClient();
		   DB db = mongoClient.getDB("test");
		   
		   DBCollection table = db.getCollection("sample");	
		   if(table.count() >= 1000){
			   table.drop();
		   }
		   for (int i = 0; i < 1000; i++) {
			   table.insert(new BasicDBObject("x",i));
		   }
		   System.out.println(table.count());
		   DBCursor cursor = table.find();
		   
		   System.out.println(cursor.count());
		   while( cursor.hasNext() )  {
		     DBObject ob = cursor.next(); 
		     System.out.println(ob.get("x"));
		   }
		   System.out.println("-----------------------------------------------");
		   List<DBObject> list = table.find().skip(10).limit(70).toArray();
		   System.out.println(list.toString());
		   DBCursor cursor1 = table.find().skip(100).limit(100);
		   while( cursor1.hasNext() )  {
			     DBObject o = cursor1.next(); 
			     System.out.println(o.get("x"));
		   }
		   cursor.close();
		   cursor1.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (MongoException e) {
			e.printStackTrace();
		}
	}

}
