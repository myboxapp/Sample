package com.jpmorgan.mongodb;

public class DeleteExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
