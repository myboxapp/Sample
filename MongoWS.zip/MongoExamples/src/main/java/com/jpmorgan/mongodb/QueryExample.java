package com.jpmorgan.mongodb;

import java.util.ArrayList;
import java.util.List;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.util.JSON;

public class QueryExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			Mongo mongo = new Mongo("localhost", 27017);
			DB db = mongo.getDB("test");
		    String json = "{ '_id' : { '$oid' : 'id'} , 'number' : 1 , 'name' : 'user-1'}{ '_id' : { '$oid' : 'id'} , 'number' : 2 , 'name' : 'user-2'}{ '_id' : { '$oid' : 'id'} , 'number' : 3 , 'name' : 'user-3'}{ '_id' : { '$oid' : 'id'} , 'number' : 4 , 'name' : 'user-4'}{ '_id' : { '$oid' : 'id'} , 'number' : 5 , 'name' : 'user-5'}";
			DBObject dbObject = (DBObject)JSON.parse(json);
			DBCollection collection = db.getCollection("testtable");
			collection.insert(dbObject);
			
			DBObject doc = collection.findOne();
			System.out.println(dbObject);
			
			DBCursor cursor = collection.find();
			while(cursor.hasNext()) {
			    System.out.println(cursor.next());
			}
			
			BasicDBObject allQuery = new BasicDBObject();
			BasicDBObject fields = new BasicDBObject();
			fields.put("name", 1);
		 
			DBCursor cursor2 = collection.find(allQuery, fields);
			while (cursor2.hasNext()) {
				System.out.println(cursor2.next());
			}
			
			BasicDBObject whereQuery = new BasicDBObject();
			whereQuery.put("number", 5);
			DBCursor cursor3 = collection.find(whereQuery);
			while(cursor3.hasNext()) {
			    System.out.println(cursor3.next());
			}
			
			BasicDBObject inQuery = new BasicDBObject();
			List<Integer> list = new ArrayList<Integer>();
			list.add(2);
			list.add(4);
			list.add(5);
			inQuery.put("number", new BasicDBObject("$in", list));
			DBCursor cursor4 = collection.find(inQuery);
			while(cursor4.hasNext()) {
				System.out.println(cursor4.next());
			}
			
			BasicDBObject gtQuery = new BasicDBObject();
			gtQuery.put("number", new BasicDBObject("$gt", 2).append("$lt", 5));
			DBCursor cursor5 = collection.find(gtQuery);
			while(cursor5.hasNext()) {
				System.out.println(cursor5.next());
			}
			
			BasicDBObject neQuery = new BasicDBObject();
			neQuery.put("number", new BasicDBObject("$ne", 4));
			DBCursor cursor6 = collection.find(neQuery);
			while(cursor6.hasNext()) {
				System.out.println(cursor6.next());
			}
			
		}catch(Exception ex){
			
		}
	}

}
